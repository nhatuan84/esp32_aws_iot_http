CBMC proof source code
======================

This directory contains source code written for CBMC proofs.  It is
common to write some code to model aspects of the system under test,
and this code goes here.
