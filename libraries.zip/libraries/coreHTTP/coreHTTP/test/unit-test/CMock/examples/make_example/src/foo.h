#ifndef _foo_h

void foo_init(void);

#endif
