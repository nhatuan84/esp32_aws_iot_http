<table>
    <tr>
        <td colspan="3"><center><b>Code Size of coreHTTP (example generated with GCC for ARM Cortex-M)</b></center></td>
    </tr>
    <tr>
        <td><b>File</b></td>
        <td><b><center>With -O1 Optimization</center></b></td>
        <td><b><center>With -Os Optimization</center></b></td>
    </tr>
    <tr>
        <td>core_http_client.c</td>
        <td><center>3.3K</center></td>
        <td><center>2.7K</center></td>
    </tr>
    <tr>
        <td>api.c (llhttp)</td>
        <td><center>2.8K</center></td>
        <td><center>2.2K</center></td>
    </tr>
    <tr>
        <td>http.c (llhttp)</td>
        <td><center>0.3K</center></td>
        <td><center>0.3K</center></td>
    </tr>
    <tr>
        <td>llhttp.c (llhttp)</td>
        <td><center>19.1K</center></td>
        <td><center>17.1K</center></td>
    </tr>
    <tr>
        <td><b>Total estimates</b></td>
        <td><b><center>25.5K</center></b></td>
        <td><b><center>22.3K</center></b></td>
    </tr>
</table>
