<table>
    <tr>
        <td colspan="3"><center><b>Code Size of AWS IoT Jobs (example generated with GCC for ARM Cortex-M)</b></center></td>
    </tr>
    <tr>
        <td><b>File</b></td>
        <td><b><center>With -O1 Optimization</center></b></td>
        <td><b><center>With -Os Optimization</center></b></td>
    </tr>
    <tr>
        <td>jobs.c</td>
        <td><center>2.8K</center></td>
        <td><center>2.5K</center></td>
    </tr>
    <tr>
        <td>job_parser.c</td>
        <td><center>0.9K</center></td>
        <td><center>0.9K</center></td>
    </tr>
    <tr>
        <td>ota_job_handler.c</td>
        <td><center>0.2K</center></td>
        <td><center>0.2K</center></td>
    </tr>
    <tr>
        <td>core_json.c</td>
        <td><center>2.9K</center></td>
        <td><center>2.4K</center></td>
    </tr>
    <tr>
        <td><b>Total estimates</b></td>
        <td><b><center>6.8K</center></b></td>
        <td><b><center>6.0K</center></b></td>
    </tr>
</table>
